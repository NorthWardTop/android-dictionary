# AndroidDictionary
支持多种查词模式的安卓英语词典
